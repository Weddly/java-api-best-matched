package com.weddly.bestmatchedrestaurantswr;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

@SpringBootTest
@AutoConfigureMockMvc
public class RestaurantControllerTests {
    @Autowired
    private MockMvc mockMvc;

    @Test
    public void testSearchWithRequiredParamenterName() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/list")
                .param("name", "Bar")
                .param("price", "10")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    public void testSearchWithOutRequiredParamenterName() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/list")
                .param("price", "10")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    @Test
    public void testSearchWithInvalidOptionalParamenter() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/list")
                .param("name", "your_search_query")
                .param("price", "7")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.content().string("Error: price must be an Integer between 10 and 50"));
    }

    @Test
    public void testSearchAll() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/listAll")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }
    
}
