package com.weddly.bestmatchedrestaurantswr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BestMatchedRestaurantsWrApplicationTests {

	@Test
	void contextLoads() {
	}

}
